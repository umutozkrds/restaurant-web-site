<?php

include 'includes/baglan.php';

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baytar Restorant</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
<div id="nav">
    <a href=""><img id="logo" src="img/logo.png" alt=""></a>
    <div id="navback">
        <div id="menu-selection">
            <ul id="selection">
                <li class="list-selection"><a href="index.php"><span id="orange-home">Anasayfa</span></a></li>
                <li class="list-selection"><a href="menu.php">Menü</a></li>
                <li class="list-selection"><a href="hakkimizda.php">Hakkımızda</a></li>
                <li class="list-selection"><a href="iletisim.php">İletişim</a></li>
                <li class="list-selection"><a href="rezervasyon.php">Rezervasyon Yap</a></li>
            </ul>
        </div>
    </div>
</div>


<div class="container mt-5">
    <div class="jumbotron">
        <h1 class="display-4">Hakkımızda</h1>
        <p class="lead">Hoş Geldiniz! BAYTAR RESTAURANT'a Dair Bir Hikaye
Merhaba, değerli misafirlerimiz! Biz, BAYTAR RESTAURANT ailesi olarak, sizleri lezzet dolu bir yolculuğa davet etmekten büyük bir mutluluk duyuyoruz. BAYTAR RESTAURANT, yemek kültürünü zenginleştiren, damakları şenlendiren ve kaliteyi ön planda tutan bir anlayışla hizmet veren bir aile işletmesidir.
Bizler, yemek yapma sanatında ustalaşmış bir ekibin bir araya gelerek hayata geçirdiği bir rüyayız. Mutfağımızda kullanılan taze ve en kaliteli malzemeleri seçerken özen gösteriyor, her bir yemeği özel bir lezzet şölenine dönüştürüyoruz. Geleneksel ve modern mutfak tekniklerini bir araya getirerek, sizlere benzersiz bir gastronomik deneyim sunmaya çalışıyoruz.
BAYTAR RESTAURANT'ın öyküsü, lezzetin sınırlarını zorlamak ve misafirlerimizi memnun etmek için var gücümüzle çalışmakla başlıyor. Her bir tabak, özenle seçilmiş tariflerimizin birer sanat eseridir ve sizlere, damak zevkinize hitap eden bir menü sunma amacını taşır.
Ama BAYTAR RESTAURANT sadece yemeklerden ibaret değil; burası bir araya gelmenin, paylaşmanın ve özel anları kutlamanın bir mekanıdır. Sıcak ve samimi atmosferimizde, ailemizin bir parçası olduğunuzu hissedecek, unutulmaz anlar yaşayacaksınız.
Biz, sadece yemek yapmıyoruz, aynı zamanda sizinle bir bağ kuruyoruz. Sizlerle birlikte güzel anılar biriktirmek, sofralarınıza keyif katmak ve misafirperverliğimizle sizi ağırlamak için buradayız.
Bize gösterdiğiniz ilgi ve sevgiye teşekkür ederiz. Sizleri BAYTAR RESTAURANT'a bekliyor, sizi ağırlamaktan mutluluk duyacağımız günü sabırsızlıkla bekliyoruz.

Lezzet dolu günler dileriz!

Saygılarımızla,

BAYTAR RESTAURANT Ailesi</p>
        <hr class="my-4">
        <p>It uses utility classes for typography and spacing to space content out within the larger container.</p>
        <a class="btn btn-primary btn-lg" href="rezervasyon.php" role="button">Rezervasyon Yap</a>
    </div>
</div>


<div class="container">
    <h1 class="text-center">Ekibimiz</h1>
    <div class="card-deck mt-3">
        <div class="card">
            <img class="card-img-top" src="https://st.depositphotos.com/1499736/4858/i/450/depositphotos_48589235-stock-photo-male-chef-with-arms-crossed.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Sefa Yıldırım</h5>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQsi4D6qCHXRpfcD4F72kixSp51LPyDkhPCA&usqp=CAU" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Kaan Aygün</h5>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTe8eAhyFADiq2YTaV8D_OgjgbCn2QiMkHeQ&usqp=CAU" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Muhammet Eren Turgut</h5>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="https://iyikigormusum.com/public/uploads/files/gordonramsay.jpg" alt="Card image cap">
            <div class="card-body">
                <h5 class="card-title">Umut Özkardeş </h5>
                <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
            </div>
        </div>

    </div>
</div>


<br><br><br>
<footer class="footer">
    <div class="footer-content">
        <div class="left-side">
            <img src="img/logo.png" alt="İşletme Logosu">
        </div>
        <div class="right-side">
            <p>Tüm hakları saklıdır © 2023</p>
            <div class="social-media">
                <!-- Diğer sosyal medya logoları için benzer şekilde devam edebilirsin -->
            </div>
        </div>
    </div>
</footer>

</body>
</html>