-- --------------------------------------------------------
-- Sunucu:                       127.0.0.1
-- Sunucu sürümü:                8.0.30 - MySQL Community Server - GPL
-- Sunucu İşletim Sistemi:       Win64
-- HeidiSQL Sürüm:               12.6.0.6765
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- rest için veritabanı yapısı dökülüyor
CREATE DATABASE IF NOT EXISTS `rest` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `rest`;

-- tablo yapısı dökülüyor rest.feedback
CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `phone_number` varchar(11) COLLATE utf8mb4_general_ci NOT NULL,
  `message` text COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- rest.feedback: ~1 rows (yaklaşık) tablosu için veriler indiriliyor
INSERT INTO `feedback` (`id`, `name`, `email`, `phone_number`, `message`) VALUES
	(6, 'Sefa ', 'xutkpn@outlook.com', '5441156320', 'ASDSADAS');

-- tablo yapısı dökülüyor rest.menu
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `content` text COLLATE utf8mb4_general_ci NOT NULL,
  `price` float NOT NULL,
  `image` varchar(250) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- rest.menu: ~4 rows (yaklaşık) tablosu için veriler indiriliyor
INSERT INTO `menu` (`id`, `title`, `content`, `price`, `image`) VALUES
	(1, 'Serpme Kahvaltı', 'Sucuk, Pastırma, Sigara Böreği, Zeytin, Yeşil Zeytin, Beyaz peynir, Kaşar peyniri, Domates, Salatalık, Reçel,Bal, Tereyağı,Haşlanmış yumurta, Termos çay', 350, 'card4'),
	(2, 'Margarita Pizza', 'Domates, Mozerella, Fesleğen, Zeytinyağı, Tuz\r\n\r\nİsteğe bağlı: Parmesan, Mantar, Jambon, Ekstra Mozerella', 150, 'card1'),
	(3, 'Penne Makarna', 'Domates Sosu, Krema, Karabiber, Parmesan, Sarımsak, Soğa, Fesleğen\r\n\r\nİsteğe Bağlı: Tavuk, Mantar, Karides, Brokoli, Nane', 60, 'card2'),
	(4, 'CupCake ', 'Kakaolu Kek Üzerine Krema, Çikolata Parçacıkları\r\nİsteğe Bağlı: Limonlu Kek, Çilekli Kek, Kivi, Çilek, Çikolata, Çilek sosu', 60, 'card3');

-- tablo yapısı dökülüyor rest.rezervasyon
CREATE TABLE IF NOT EXISTS `rezervasyon` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `phone_number` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  `table_number` tinyint NOT NULL,
  `date` datetime NOT NULL,
  `meal` varchar(50) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- rest.rezervasyon: ~7 rows (yaklaşık) tablosu için veriler indiriliyor
INSERT INTO `rezervasyon` (`id`, `name`, `email`, `phone_number`, `table_number`, `date`, `meal`) VALUES
	(9, 'Sefa ', 'xutkpn@outlook.com', '5441156320', 1, '2023-12-28 18:41:00', 'kahvalti'),
	(10, 'Sefa ', 'xutkpn@outlook.com', '5441156320', 4, '2023-12-27 18:42:00', 'aksam-yemegi'),
	(11, 'Sefa ', 'xutkpn@outlook.com', '5441156320', 6, '2023-12-27 18:42:00', 'aksam-yemegi'),
	(12, 'Sefa ', 'xutkpn@outlook.com', '5441156320', 10, '2023-12-29 18:42:00', 'aksam-yemegi'),
	(13, 'Sefa ', 'xutkpn@outlook.com', '5441156320', 1, '2023-12-29 18:42:00', 'aksam-yemegi'),
	(14, 'Sefa ', 'xutkpn@outlook.com', '5441156320', 10, '2023-12-28 18:42:00', 'aksam-yemegi'),
	(15, 'Sefa ', 'xutkpn@outlook.com', '5441156320', 1, '2023-12-28 18:42:00', 'aksam-yemegi');

-- tablo yapısı dökülüyor rest.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(30) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- rest.users: ~0 rows (yaklaşık) tablosu için veriler indiriliyor

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
