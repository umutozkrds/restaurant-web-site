<?php

include "includes/baglan.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone_number = $_POST["phone_number"];
    $message = $_POST["message"];

    $sql = "INSERT INTO feedback (name, email, phone_number, message) VALUES ('$name', '$email', '$phone_number', '$message')";

    if (mysqli_query($connection, $sql)) {
        echo '<script>window.location.href = "iletisim.php"; alert("Mesajınız Gönderildi!");</script>';
    } else {
        echo "Hata: " . $sql . "<br>" . mysqli_error($connection);
    }
}

?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <link rel="stylesheet" href="iletisim.css">
</head>
<body>
<div id="nav">
        <a href=""><img id="logo"
            src="img/logo.png"
            alt=""></a>
        <div id="navback">
            <div id="menu-selection">
                <ul id="selection">
                    <li class="list-selection"><a href="index.php"><span id="orange-home">Anasayfa</span></a></li>
                    <li class="list-selection"><a href="menu.php">Menü</a></li>
                    <li class="list-selection"><a href="hakkimizda.php">Hakkımızda</a></li>
                    <li class="list-selection"><a href="iletisim.php">İletişim</a></li>
                    <li class="list-selection"><a href="rezervasyon.php">Rezervasyon Yap</a></li>
                </ul>
            </div>
        </div>
    </div>
    <br><br><br>

    <div class="contact-info">
        <table border="5">
        <th colspan="2" style="text-align: center;"><h2 style="text-align: center; color:black;">İletişim Bilgilerimiz</h2></th>
        <tbody>
        
        <tr>
            <td><b>Adresimiz</b></td>
            <td><b>İnönü, Leylaklar Sk. 19-17, 34755 Dudullu Osb/Ataşehir/İstanbul</b></td>
        </tr>
        <tr>
            <td><b>E-Posta Adresimiz</b></td>
            <td><b>iletisim@isyeri.com</b></td>
        </tr>
        <tr>
            <td><b>Telefon Numaramız</b></td>
            <td><b>05648546547 <br>02124586574</b></td>
        </tr>
        <tr>
            <td><b>Google Haritalar Ulaşım </b></td>
            <td><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6024.519708525273!2d29.13405969789722!3d40.97579043542009!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14cac5e28f13aa33%3A0x350342f0b77657da!2zxLBuw7Zuw7wsIDM0NzU1IEF0YcWfZWhpci_EsHN0YW5idWw!5e0!3m2!1str!2str!4v1703165667160!5m2!1str!2str"
                 width="400" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></td>
        </tr>
    </tbody>
         </table>
    </div>

    <form method="POST" action="iletisim.php">
        <h2 style="text-align: center;"><b>İletişim Formu</b></h2>

        <label for="name"><b>Ad:</b></label>
        <input type="text" id="name" name="name" required>

        <label for="email"><b>Email:</b></label>
        <input type="email" id="email" name="email" required>

        <label for="phone"><b>Telefon:</b></label>
        <input type="tel" id="phone" name="phone_number" pattern="[0-9]{10}" placeholder="Örneğin: 5551234567" required>

    
        <label for="message"><b>Öneri & Şikayet & Destek &  Mesajınız:</b></label>
        <textarea placeholder="Mesajınızı Giriniz ..." type="text" id="message" name="message" required style="height: 200px; width: 300px;"></textarea>

        <button  type="submit" ><b>Gönder</b></button>
        
    </form>

 

    <script>
        function submitForm() {
            var firstName = document.getElementById('firstName').value;
            var lastName = document.getElementById('lastName').value;
            var phone = document.getElementById('phone').value;
            var message = document.getElementById('message').value;

        }
    </script>

</body>
</html>