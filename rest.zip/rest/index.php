<?php


include 'includes/baglan.php';

$sql = "SELECT * FROM menu";
$result = $connection->query($sql);


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone_number = $_POST["phone_number"];
    $table_number = $_POST["table_number"];

    // Tarih formatını 'Y-m-d H:i:s' olarak oluştur
    $date = date("Y-m-d H:i:s", strtotime($_POST["date"]));

    $meal = $_POST["meal"];

    // Önce var olan rezervasyonları kontrol et
    $check_sql = "SELECT * FROM rezervasyon WHERE table_number = ? AND DATE(date) = DATE(?)";
    $check_stmt = $connection->prepare($check_sql);
    $check_stmt->bind_param("is", $table_number, $date);
    $check_stmt->execute();
    $result = $check_stmt->get_result();

    if ($result->num_rows > 0) {
        // Masa dolu, uyarı ver
        echo '<script>window.location.href = "index.php"; alert("Bu gün için seçtiğiniz masa dolu, lütfen başka bir masa veya tarih seçin!");</script>';
    } else {
        // Masa boş, rezervasyonu kaydet
        $insert_sql = "INSERT INTO rezervasyon (name, email, phone_number, table_number, date, meal) 
                       VALUES (?, ?, ?, ?, ?, ?)";
        $insert_stmt = $connection->prepare($insert_sql);
        $insert_stmt->bind_param("ssisss", $name, $email, $phone_number, $table_number, $date, $meal);

        if ($insert_stmt->execute()) {
            echo '<script>window.location.href = "index.php"; alert("Rezervasyon başarıyla oluşturuldu!");</script>';
        } else {
            echo "Hata: " . $insert_stmt->error;
        }
    }
}


?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baytar Restorant</title>
    <link rel="stylesheet" href="index.css">

</head>
<body>
<div id="nav">
    <a href=""><img id="logo" src="img/logo.png" alt=""></a>
    <div id="navback">
        <div id="menu-selection">
            <ul id="selection">
                <li class="list-selection"><a href="index.php"><span id="orange-home">Anasayfa</span></a></li>
                <li class="list-selection"><a href="menu.php">Menü</a></li>
                <li class="list-selection"><a href="hakkimizda.php">Hakkımızda</a></li>
                <li class="list-selection"><a href="iletisim.php">İletişim</a></li>
                <li class="list-selection"><a href="rezervasyon.php">Rezervasyon Yap</a></li>
            </ul>
        </div>
    </div>
</div>

<div id="content">
    <div id="left-content">
        <button id="rezervasyon">Rezervasyon Yapın</button>
    </div>
    <div id="right-content">
        <img class="slider" src="img/slide1.jpg" alt="slide1">
        <img class="slider" src="img/slide2.jpg" alt="slide2">
        <img class="slider" src="img/slide3.jpg" alt="slide3">
    </div>
</div>
<div id="about">
    <div id="about-write">
        <br><br><br>
        <h6>--Hakkımızda--</h6>
        <h2>LEZZETLİ BİR ANI İÇİN..</h2>
        <br>
        <p id="about-us">Umut Restaurant, lezzetli yemeklerin ve sıcak bir atmosferin mükemmel bir buluşma noktasıdır.
            20 yılı aşkın deneyimimizle, misafirlerimize unutulmaz bir yemek deneyimi sunmak için buradayız.
            Ailece, arkadaşlarınızla veya iş yemekleri için ideal bir mekanız. Biz, her ziyaretinizi özel kılmak ve sizi
            ağırlamaktan mutluluk duyuyoruz.
            <br><br>
            Umut Restaurant'a hoş geldiniz, burası sadece yemek yemek değil, keyifli anılar biriktirmek için bir mekan.
        </p>
        <br>
        <img src="img/cook1.jpg" alt="cook1">
        <img class="cook-slide" src="img/cook2.jpg" alt="cook2">
        <img class="cook-slide" src="img/cook3.jpg" alt="cook3">
    </div>
    <div id="about-img">
        <img src="img/about.jpg" alt="">
    </div>

</div>
<br><br><br><br>
<div id="the-menu">
    <div id="row">
        <h6>--Menümüz--</h6>
        <h2>DAMAĞINIZA UYGUN LEZZETİ SEÇİN..</h2>
    </div>
    <div id="our-menu">
        <?php
            while ($row = $result->fetch_assoc()) {
            $menuTitle = $row['title'];
            $menuContent = $row['content'];
            $menuPrice = $row['price'];
            $menuImage = $row['image'];
            ?>
            <div id="serpme" class="card">
                <img src="img/<?= $menuImage ?>.jpeg" alt="serpme">
                <div id="serpmeH" class="info-menu">
                    <h4><?= $menuTitle . ' ' . $menuPrice; ?>₺</h4>
                    <p><?= $menuContent ?></p>
                </div>
            </div>
        <?php } ?>
    </div>

</div>

<div id="rezerv">
    <div id="masa">
        <h2 style="text-align: center">Bugün Boş Olan Masalar</h2>
        <div class="container">
            <?php
            date_default_timezone_set('Europe/Istanbul'); // İstanbul zaman dilimi

            // Belirli bir tarih için rezerve edilen masaları getiren bir fonksiyon
            function getReservedTables($connection, $date) {
                $sql = "SELECT table_number FROM rezervasyon WHERE DATE(date) = ?";
                $stmt = $connection->prepare($sql);
                $stmt->bind_param("s", $date);
                $stmt->execute();
                $result = $stmt->get_result();

                $reservedTables = [];
                while ($row = $result->fetch_assoc()) {
                    $reservedTables[] = $row['table_number'];
                }

                return $reservedTables;
            }

            // Bugünün tarihini al
            $currentDate = date("Y-m-d");


            // Rezerve edilen masaların numaralarını al
            $reservedTables = getReservedTables($connection, $currentDate);

            echo '<div class="row">';
            for ($i = 1; $i <= 20; $i++) {
                $backgroundStyle = in_array($i, $reservedTables) ? 'background-color: gray;' : '';
                echo '<div style="' . $backgroundStyle . '" class="box">' . $i . '</div>';
                if ($i % 5 == 0 && $i != 20) {
                    echo '</div><div class="row">';
                }
            }
            echo '</div>';
            ?>

        </div>
    </div>
    <div id="rezervform">
        <h4>Rezervasyon Yapın</h4>
        <form action="" method="post">
            <div class="form-container">
                <div class="input-group">
                    <label for="username">Kullanıcı Adı:</label>
                    <input type="text" id="username" name="name" placeholder="Kullanıcı adınızı girin" required>
                </div>
                <div class="input-group">
                    <label for="email">E-posta Adresi:</label>
                    <input type="email" id="email" name="email" placeholder="E-posta adresinizi girin" required>
                </div>
                <div class="input-group">
                    <label for="phone">Telefon Numarası:</label>
                    <input type="tel" id="phone" name="phone_number" placeholder="Telefon numaranızı girin" required>
                </div>
                <div class="input-group">
                    <label for="quantity">Masa Seçimi (1-20):</label>
                    <input type="number" id="quantity" name="table_number" min="1" max="20" required>
                </div>
                <div class="input-group">
                    <label for="date">Tarih Seçimi:</label>
                    <input type="datetime-local" id="date" name="date" required>
                </div>
                <div class="input-group">
                    <label for="meal">Öğün Seçimi:</label>
                    <select id="meal" name="meal" required>
                        <option value="kahvalti">Kahvaltı</option>
                        <option value="ogle-yemegi">Öğle Yemeği</option>
                        <option value="aksam-yemegi">Akşam Yemeği</option>
                    </select>
                </div>
            </div>
            <br>
            <br>
            <button style="margin-left: 120px" type="submit">Rezervasyon Yap</button>
        </form>
    </div>
</div>


<br><br><br>
<footer class="footer">
    <div class="footer-content">
        <div class="left-side">
            <img src="img/logo.png" alt="İşletme Logosu">
        </div>
        <div class="right-side">
            <p>Tüm hakları saklıdır © 2023</p>
            <div class="social-media">
                <!-- Diğer sosyal medya logoları için benzer şekilde devam edebilirsin -->
            </div>
        </div>
    </div>
</footer>
<script>
    document.getElementById('rezervasyon').addEventListener('click', function () {
        window.location.href = '#rezervform';
    });

    let slideIndex = 0;
    showSlides();

    function showSlides() {
        let i;
        const slides = document.getElementsByClassName("slider");

        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }

        slideIndex++;

        if (slideIndex > slides.length) {
            slideIndex = 1;
        }

        slides[slideIndex - 1].style.display = "block";

        setTimeout(showSlides, 2000); // 2 saniyede bir resim değişecek, istediğiniz zaman aralığını ayarlayabilirsiniz
    }

    const numberSelector = document.getElementById('quantity');
    const boxes = document.querySelectorAll('.box');

    numberSelector.addEventListener('change', function () {
        const selectedNumber = parseInt(this.value);

        boxes.forEach(box => {
            const boxNumber = parseInt(box.textContent);
            if (boxNumber === selectedNumber) {
                box.style.backgroundColor = 'green';
            } else {
                box.style.backgroundColor = '';
            }
        });
    });

</script>
</body>
</html>