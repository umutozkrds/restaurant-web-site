<?php


include 'includes/baglan.php';
$sql = "SELECT * FROM menu";
$result = $connection->query($sql);

?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Baytar Restorant</title>
    <link rel="stylesheet" href="index.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>
<body>
<div id="nav">
    <a href=""><img id="logo"
                    src="img/logo.png"
                    alt=""></a>
    <div id="navback">
        <div id="menu-selection">
            <ul id="selection">
                <li class="list-selection"><a href="index.php"><span id="orange-home">Anasayfa</span></a></li>
                <li class="list-selection"><a href="menu.php">Menü</a></li>
                <li class="list-selection"><a href="hakkimizda.php">Hakkımızda</a></li>
                <li class="list-selection"><a href="iletisim.php">İletişim</a></li>
                <li class="list-selection"><a href="rezervasyon.php">Rezervasyon Yap</a></li>
            </ul>
        </div>
    </div>
</div>

<br><br><br><br><br><br><br><br><br><br>

<h1 class="text-center">Menümüz</h1>
<div class="container">
    <div class="row">
        <?php
        // Verileri foreach döngüsü ile çek
        while ($row = $result->fetch_assoc()) {
        $menuTitle = $row['title'];
        $menuContent = $row['content'];
        $menuPrice = $row['price'];
        $menuImage = $row['image'];
        ?><br><br>
        <div class="col-md-4 mt-4">
                <div class="card" style="width: 22rem;">
                    <img style="height: 380px" src="img/<?= $menuImage ?>.jpeg" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?= $menuTitle . ' ' . $menuPrice; ?>₺</h5>
                        <p class="card-text"><?= $menuContent ?></p>
                    </div>
                </div>
        </div>
            <br>
        <?php } ?>

    </div>
</div>



<br><br><br>
<br><br><br>
<br><br><br>
<br><br><br>
<footer class="footer">
    <div class="footer-content">
        <div class="left-side">
            <img src="img/logo.png" alt="İşletme Logosu">
        </div>
        <div class="right-side">
            <p>Tüm hakları saklıdır © 2023</p>
            <div class="social-media">
                <!-- Diğer sosyal medya logoları için benzer şekilde devam edebilirsin -->
            </div>
        </div>
    </div>
</footer>
<script>

</script>
</body>
</html>